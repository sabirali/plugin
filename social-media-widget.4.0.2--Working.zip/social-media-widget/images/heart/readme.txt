Credits For This Icon Set Go To The Design Superhero:
Heart v2:

http://thedesignsuperhero.com/2009/03/heart-v2-free-social-iconset-in-heart-shape/