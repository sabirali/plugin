Credits For This Icon Set Go To ~TheG-Force via:
http://theg-force.deviantart.com/art/Social-Icons-hand-drawned-109467069\

E-mail icon: Janko At Warp Speed - Handycons via http://www.jankoatwarpspeed.com/post/2008/10/20/handycons-a-free-hand-drawn-social-media-icon-set.aspx