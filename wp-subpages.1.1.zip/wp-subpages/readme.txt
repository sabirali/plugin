=== Plugin Name ===
Contributors: blondishnet
Plugin Name: WP Subpages
Donate link: http://blondish.net/donate/
Plugin URI:  http://wpaddict.net/plugin-development/wp-subpages/
Author URI:  http://blondish.net
Tags: subpages, widget, pages, child pages
Requires at least: 2.8
Tested up to: 3.0
Stable tag: 1.1

WP Subpages Widget is a simple plugin to allow for multiple instances to show child pages.

== Description ==

WP Subpages Widget is a simple plugin to allow for multiple instances to show child pages. For people who use multiple template files for each of their site's pages, having the capability of using a widget, rather than hardcode subpages of a parent or child page.


== Installation ==


1. Upload folder called `wp-subpages` to the `/wp-content/plugins/` directory or use the automatic install available by WordPress
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Simply go to Appearance -> Widgets and select Subpages widget. Put it into your widget area and configure as desired.

== Frequently Asked Questions ==

= How do I configure this widget? =

Simply drag the widget over to the sidebar you want. You can customize the title or use the page. After that, select the parent page from the drop down.

= Can I contribute to this plugin project some code? =

By all means, yes. Contact me, make sure you are signed up with WordPress.org and I will even give you credit.

== Upgrade Notice ==

None at this moment

== Screenshots ==

None at this moment


== Changelog ==

= 1.1 =
* Tested for 3.0

= 1.0 =
* First release








