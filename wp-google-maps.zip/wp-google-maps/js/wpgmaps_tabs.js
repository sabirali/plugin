jQuery("document").ready(function() {
   jQuery("#wpgmaps_tabs").tabs();
   jQuery("#wpgmaps_tabs_markers").tabs(); 
});