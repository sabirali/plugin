# TODO Testimonials Widget

Is there something you want done? Write it up on the [support forums](http://wordpress.org/support/plugin/testimonials-widget) and then [donate](http://aihr.us/about-aihrus/donate/) or [write an awesome testimonial](http://aihr.us/about-aihrus/testimonials/add-testimonial/).

* 3.X Remove prior version options
* Add easing options - http://bxslider.com/examples/easing, http://gsgd.co.uk/sandbox/jquery/easing/
* BUG Saving settings doesn't show update notice
* Consolidate schema by testimonial item 
* Show settings save errors in error notices
* [CONFLICT](https://aihrus.zendesk.com/agent/#/tickets/562) Widgets Reloaded plugin - no longer allow me to exclude categories
