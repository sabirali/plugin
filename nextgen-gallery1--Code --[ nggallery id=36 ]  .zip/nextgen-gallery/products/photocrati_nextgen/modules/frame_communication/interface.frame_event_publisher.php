<?php

interface I_Frame_Event_Publisher
{
	
}