<?php

interface I_Fs
{
	
}