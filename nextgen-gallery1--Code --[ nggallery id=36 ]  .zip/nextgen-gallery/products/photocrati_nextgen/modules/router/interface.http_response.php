<?php

interface I_Http_Response
{
	function http_301_action();
	function http_302_action();
}