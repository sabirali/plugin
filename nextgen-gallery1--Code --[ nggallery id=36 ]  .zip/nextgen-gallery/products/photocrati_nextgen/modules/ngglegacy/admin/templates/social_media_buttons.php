<div id="ngg_social_media">
	<?php include('twitter_follow_link.php'); ?>
	<?php include('facebook_like_button.php'); ?>
</div>