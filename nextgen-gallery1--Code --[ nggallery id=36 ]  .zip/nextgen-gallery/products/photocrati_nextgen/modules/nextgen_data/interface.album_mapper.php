<?php

interface I_Album_Mapper
{
	
}