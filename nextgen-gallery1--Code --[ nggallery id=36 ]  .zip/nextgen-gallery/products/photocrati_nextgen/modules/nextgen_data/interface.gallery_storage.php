<?php

interface I_Gallery_Storage
{
	static function get_instance($context = False);
}
