This email can be seen only on rich text email client. To see it online visit:

{email_url}

To change your subscription visit:

{profile_url}

Thank you!