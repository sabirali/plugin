# TODO Testimonials Widget

Is there something you want done? Write it up on the [support forums](http://wordpress.org/support/plugin/testimonials-widget) and then [donate](http://aihr.us/about-aihrus/donate/) or [write an awesome testimonial](http://aihr.us/about-aihrus/testimonials/add-testimonial/).

* Add helper tip windows
* Adjust [fadeIn speed](http://wordpress.org/support/topic/animation-not-disabling)
* BUG [IE8 + Google Font Issue](http://wordpress.org/support/topic/ie8-google-font-issue)
* Offer slideUp option
* Pass YSlow and Google PageSpeed testing
* Prevent page slug naming conflicts
* Saved settings message
* [Begin CSS testing](http://www.netmagazine.com/tutorials/4-tools-automatic-css-testing)