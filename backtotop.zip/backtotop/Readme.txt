=== Back To Top ===
Contributors: Arkaprava Majumder
Tags: backtotop,scrolltotop, top, smooth scroll to top
Requires at least: 2.5.1
Tested up to: 3.6.1
Stable tag: trunk
License: GPL or later

This plugin will create a "back to top" or "scroll to top button" for your website.
== Description ==

This plugin will create a "back to top" or "scroll to top button" for your website. You can select an image from list or upload your own image or create an button using text. Total solution of Back To Top button.
Demo link:http://www.pilgrimsholidays.com 


Download BackToTop Version 1.0 (Easy Installation):
http://www.mediafire.com/download/2l4x8tbuaf49q6s/backtotop.zip 
  
Developed By : Arkaprava majumder (http://arkapravamajumder.com)

== Installation ==

1. Download Back To Top.
2. Upload to your Site,(/wp-content/plugins/)
3. Activate it.

Now, Go to ,Back To Top ---->Then, Back To Top Options ----> Choose An Option ----> 1) Choose An Image From The Given List or 2) Upload Your Back To Top Image or 3) Create A Back To Top Button With Text

Then Click "Next...".

Corresponding option box will open, just do it as you want.

Yeah! You're almost done!

If you are crazzy, want to customize more, then click "Back To Top Settings" ----> Then choose a effect like (SlideUp/SlideDown or FadeIn/FadeOut or Hide/Show),
You can also customize Css too.
Just edit Css & Hover css, then Save it.

YO. 

All IZZ READY. 

NOW, YOU CAN CHECK BACK TO TOP ON YOUR WEBSITE.
For more help or customization, feel free to contact with me.
http://arkapravamajumder.com

Uninstalling is as simple as deactivating the plugin.


== Frequently Asked Questions ==

None yet, if you have one post it at http://arkapravamajumder.com 
or, Fb me Arkaprava majumder (http://fb.com/arkaindas)
or, Tweet me (http://twitter.com/arkaindas)

== Change Log ==
= Version 2.0 =
= Version 1.0 =

== Upgrade Notice ==
= 2.0 =
Yeah.Now version 2 available with totally customizable solution.


== Screenshots ==

1. Website or Front End Screenshot
2. Admin panel or back End Screenshot
3. Back To Top Settings
