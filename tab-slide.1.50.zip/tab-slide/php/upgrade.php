<?php
// Handles all current and future upgrades for tab_slide
function tab_slide_upgrade( $from ) {
	if ( !$from || version_compare( $from, '1.0', '<' ) ) tab_slide_upgrade_10();
	if ( version_compare( $from, '1.1', '<' ) ) tab_slide_upgrade_11();
	if ( version_compare( $from, '1.2', '<' ) ) tab_slide_upgrade_12();
	if ( version_compare( $from, '1.3', '<' ) ) tab_slide_upgrade_13();
	if ( version_compare( $from, '1.4', '<' ) ) tab_slide_upgrade_14();
	if ( version_compare( $from, '1.31', '<' ) ) tab_slide_upgrade_131();
	if ( version_compare( $from, '1.32', '<' ) ) tab_slide_upgrade_132();
	if ( version_compare( $from, '1.33', '<' ) ) tab_slide_upgrade_133();
	if ( version_compare( $from, '1.40', '<' ) ) tab_slide_upgrade_140();
	if ( version_compare( $from, '1.50', '<' ) ) tab_slide_upgrade_150();

}
// Upgrade to 1.0
function tab_slide_upgrade_10() {
	global $tab_slide;
	$tab_slide->update_plugin_option( 'version', '1.0' );
}
// Upgrade to 1.1
function tab_slide_upgrade_11() {
	global $tab_slide;
	$tab_slide->update_plugin_option( 'version', '1.1' );
}
// Upgrade to 1.2
function tab_slide_upgrade_12() {
	global $tab_slide;
	$tab_slide->update_plugin_option( 'version', '1.2' );
	$tab_slide->update_plugin_option( 'template_pick', 'Subscribe');
	$tab_slide->update_plugin_option( 'exclude_list', '');
	$tab_slide->update_plugin_option( 'enable_timer', TRUE);
	$tab_slide->update_plugin_option( 'post_id', 2 );
	$tab_slide->update_plugin_option( 'animation_speed', 1);
	$tab_slide->update_plugin_option( 'picture_url', 'http://s.wp.com/wp-content/themes/h4/i/logo-v-rgb.png');
	$tab_slide->update_plugin_option( 'video_url', 'http://www.youtube.com/v/9yl_XPkcTl4' );
}
// Upgrade to 1.3
function tab_slide_upgrade_13() {
	global $tab_slide;
	$tab_slide->update_plugin_option( 'version', '1.3' );
	$tab_slide->update_plugin_option( 'tab_title_open', 'OPEN');
	$tab_slide->update_plugin_option( 'tab_title_close', 'CLOSE');
	$tab_slide->update_plugin_option( 'tab_slide_position', 'left');
	$tab_slide->update_plugin_option( 'include_list', '');
	$tab_slide->update_plugin_option( 'list_pick', 'all');
	$tab_slide->update_plugin_option( 'tab_color', '#C0C0C0');
	$tab_slide->update_plugin_option( 'tab_height', '70');	
	$tab_slide->update_plugin_option( 'tab_image', '');
}
// Upgrade to 1.4
function tab_slide_upgrade_14() {
	global $tab_slide;
	$tab_slide->update_plugin_option( 'version', '1.4' );
}
// Upgrade to 1.31
function tab_slide_upgrade_131() {
	global $tab_slide;
	$tab_slide->update_plugin_option( 'version', '1.31' );
}
// Upgrade to 1.32
function tab_slide_upgrade_132() {
	global $tab_slide;
	$tab_slide->update_plugin_option( 'version', '1.32' );
	$tab_slide->update_plugin_option( 'include_method', 'php' );
	$tab_slide->update_plugin_option('disabled_pages','wp-login.php, wp-register.php, iframe.php');
}
// Upgrade to 1.33
function tab_slide_upgrade_133() {
	global $tab_slide;
	$tab_slide->update_plugin_option( 'version', '1.33' );
}
// Upgrade to 1.40
function tab_slide_upgrade_140() {
	global $tab_slide;
	$tab_slide->update_plugin_option( 'version', '1.40' );
	$tab_slide->update_plugin_option( 'shortcode', 1 );
	$tab_slide->update_plugin_option( 'credentials', 'all' );
	$tab_slide->update_plugin_option( 'borders', 1 );
	$tab_slide->update_plugin_option( 'cssonly', 0 );
	$tab_slide->update_plugin_option( 'tab_type', 0 );
	$tab_slide->update_plugin_option( 'tab_width', 20 );
	$tab_slide->update_plugin_option( 'border_size', 1 );
	$tab_slide->delete_options('tab_image');
}
// Upgrade to 1.50
function tab_slide_upgrade_150() {
	global $tab_slide;
	$tab_slide->update_plugin_option( 'version', '1.50' );
}