<?php 
global $include_method, $params; 
if ($include_method !== 'php') {
	 require_once("../../../../wp-load.php");
}
wp_localize_script('tab_slider_opt', 'j_options', $params); ?><div id="my_picture" align="center"></div>
<script language="javascript">
var img_obj = "<img id='img_obj' src= '" + opt.picture_url + "'/>";
// Embed the picture into #my_picture div
jQuery('#my_picture').append(img_obj);

// Resize your image to the tab-slide height and width parameters
jQuery('#img_obj').css('width' , opt.open_width + opt.window_unit).css('height' , 'relative');
</script> 