<?php 
global $include_method, $params, $tab_slide; 
if ($include_method !== 'php') {
	 require_once("../../../../wp-load.php");
}
wp_localize_script('tab_slider_opt', 'j_options', $params);
	
	// Change the post ID to your desired post
	$myID = $tab_slide->get_plugin_option('post_id');
	
	$my_post = get_post($myID, ARRAY_A);
	$title = $my_post['post_title'];
	$content = $my_post['post_content'];
	
	echo '<h2>';
	echo $title;
	echo '</h2>';
	echo '<div class=content>';
	echo $content;
	echo '</div>';

?>