<?php 
global $include_method; 
if ($include_method !== 'php') {
	 require_once("../../../../wp-load.php");
} ?><div id="tab_slide_widget_area" align="center">
<?php 
 if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Tab Slide Widget Area')) : 
 endif;
?></div>