<?php 
global $include_method, $params; 
if ($include_method !== 'php') {
	 require_once("../../../../wp-load.php");
}
wp_localize_script('tab_slider_opt', 'j_options', $params); ?>
<div id="my_video" align="center">
</div>
<script language="javascript">
var fl_obj = jQuery("<object width='"+ opt.open_width + opt.window_unit +"' >" +
"<param name='movie' value='" + opt.video_url + "'></param>" + 
"<param name='allowFullScreen' value='true'></param>" +
"<embed src='" + opt.video_url + "' type='application/x-shockwave-flash' allowfullscreen='true' width='" + opt.open_width + opt.window_unit + "'></embed>" +
"</object>");
// Embed the video into #my_video div
jQuery('#my_video').append(fl_obj);
</script> 
