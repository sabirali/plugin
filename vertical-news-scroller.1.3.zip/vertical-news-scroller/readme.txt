=== Vertical News Scroller ===
Contributors: Nikunj Gandhi
Tags:Vertical news,Vertical scrolling news,Scrolling news WordPress,WordPress dynamic news,Free scrolling news wordpress plugin,News plugin WordPress,WordPress set post or page as news
Donate link: http://www.my-php-scripts.net/donate_for_news_scroller.php
Requires at least:3.0
Tested up to:3.5
Stable tag:1.3
Version:1.3
License:GPLv2 or later
License URI:http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Vertical News Scroller is plugin for display a vertical scrolling news for WordPress blog.Admin can manage any number of news.Admin can add,edit delete news.
 
Simple and easy news scroller.Admin can have option for display text with news or just news title only.Admin can add custom link to news.


Check official website for live demo [http://www.my-php-scripts.net/index.php/Wordpress/vertical-news-scroller-advanced.html](http://www.my-php-scripts.net/index.php/Wordpress/vertical-news-scroller-advanced.html)

*   [Live Demo](http://my-php-scripts.net/wpdemo/2013/01/30/wp-thumbnail-slider-and-wp-news-slider/)    


**Find Vertical News Scroller Pro Plugin at [Advanced PHP Scripts](http://www.my-php-scripts.net/index.php/Wordpress/vertical-news-scroller-advanced.html)**




=Features=

1. Add any number of news  
2. Display desired number of news to users.
3. Admin can manage scrolling news spped.
4. Admin can manage scrolling news height width.
5. Customized news as per your Wordpress Theme
6. No Need Of Knowledge of PHP, HTML .
7. Easy To Install Plugin
8. Premium Support Available
9. Admin can change font and other settings from css.

=Pro Version Features=

1. Now pro version has two type news style modern(jquery scroller) and classic(marquee).
2. Admin can set any post or page as a news no need to add edit news manually.
3. Go to add or edit post or page and checkbox check add this post or page as news.
4. Go to add or edit post or page and checkbox check add this post or page as news.
5. Vertical News Scroller Open news link in same window Or In new tab


[Get Support](http://www.my-php-scripts.net/index.php/Default-form.html) 


== Installation ==


This plugin is easy to install like other plug-ins of Wordpress as you need to just follow the below mentioned steps:

1. Admin can set any post or page as a news no need to add edit news manually.
2. Go to add or edit post or page and checkbox check add this post or page as news.

1. upload vertical-news-scroller folder to wp-Content/plugins folder.

2. Activate the plugin from Dashboard / Plugins window.

4. Now Plugin is Activated, Go to the Usage section to see how to use Vertical News Scroller.

### Usage ###

1.Use of Vertical News Scroller is easy after activating plugin go to Manage Scrolling News menu.

2.Add some news atleast two,three news for good,But It can be any number of news.

3.Go to Appearance-->Widgets and drag and drop "Vertical news scroll" widget to your desired location(like left,right,footer).

4.Thats it your scrolling news will appear.

5.For css changes please change it to wp-content/plugins/vertical-news-scroller/CSS/newsscrollcss.css


== Screenshots ==

1. User site preview of scrolling news
2. Widget preview admin site. 
3. Admin manage news preview.
4. Vertical News Scroller Pro version .
5. Vertical News Scroller Pro version News Scroller Type.
6. Vertical News Scroller Open news link in same window Or In new tab.


== License ==

This plugin is free for everyone! Since it's released under the GPL, you can use it free of charge on your personal or commercial blog. But you can make some donations if you realy find it useful.

== Changelog ==

= 1.3 =

* Added support for single quote and double quote in news title .

= 1.2 =

* Bug fix for adding news with single quote and double quote 
  in news content and title.

* Css changes for admin panel.

* Release Pro version.

= 1.1 =

* Css not loading issue fixed.

* Add News Form validation not working fixed.


= 1.0 =

* Stable 1.0 first release


== Upgrade Notice ==

= 1.3 =

* Added support for single quote and double quote in news title .

* Bug fix for adding news with single quote and double quote 
  in news content and title.

* Css changes for admin panel.

* Release Pro version.

= 1.1 =

* Css not loading issue fixed.

* Add News Form validation not working fixed.

= 1.0 =

* Stable 1.0 first release

 
== Frequently Asked Questions ==

1.How to use ?

For frontend side use please use widget feature.more more info use readme installation and usage notes.