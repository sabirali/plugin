=== Wordpress Gallery Plugin ===
Plugin Author: http://www.snilesh.com
Contributors: Neel
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=YKY7SHDT8GTQG
Tags: slideshow,slider,image gallery,image slider,wp gallery,wordpress slider,nivo slider,nivo,gallery plugin,image slideshow, javascript, javascript slideshow, jquery, slide show, slides, slideshow, slideshow gallery 
Requires at least: 3.0
Tested up to: 3.2
Stable tag: trunk

WordPress Gallery Plugin makes it as easy as it could possibly be to create gorgeous sliders for your WordPress powered site.

== Description ==

WordPress Gallery Plugin makes it as easy as it could possibly be to create gorgeous sliders for your WordPress powered site. Forget nasty custom fields and image URLs. You can even forget about manually resizing every image before you upload it because wordpress gallery plugin is using timthumb image resize script to auto resize images with dimensions of your choice.

= Demo's =
1. <a href="http://www.snilesh.com/resources/wordpress/wordpress-gallery-plugin/" target="_blank" title="WP Gallery Plugin">WP Gallery Plugin</a>

= Our Other Plugins =
1. <a href="http://www.snilesh.com/resources/wordpress/wordpress-plugins/wordpress-content-slide-plugin/" target="_blank" title="content slide">Content Slide</a>


Plugin Created By <a href="http://snilesh.com" target="_blank" title="Custom Wordpress Design">Snilesh.com</a>. For Plugin Information please visit <a href="http://www.snilesh.com/resources/wordpress/wordpress-gallery-plugin/" target="_blank" title="Wordpress Gallery Plugin">Wordpress Gallery Plugin</a>.

== Installation ==

* Upload the 'wp-gallery-plugin' folder to the '/wp-content/plugins/' directory.
* Activate the plugin through the 'Plugins' menu in WordPress.
* After Activation visit "Wp Gallery" Options page and set your default settings before adding shortcodes.


== Frequently Asked Questions ==


== Screenshots ==

1. Example 1 Wp Gallery Example with [wpg] shortcode.
2. Example 2 Wp Gallery Thumbnail Example with [wpg_thumb] shortcode.


== Changelog ==
= 1.4 = 
* Timthumb issue solved from previous 1.3 version.

= 1.3 = 
* Timthumb Updated

= 1.2 = 
* Timthumb Updated to 2.0

= 1.1 = 
* Plugin is compatible with wordpress 3.2 version now.
* Updated Nivo slider Js file to latest release.

= 1.0 =
* Version 1.0 First Launch.

== Other Notes ==

If you have any comments or questions please visit <a href="http://www.snilesh.com/resources/wordpress/wordpress-gallery-plugin/" target="_blank" title="Wordpress Gallery Plugin">Wordpress Gallery Plugin</a>.

= Demo's =
1. <a href="http://wordpressskins.org/wordpress-gallery-plugin" target="_blank" title="Wordpress Gallery Plugin">Wordpress Gallery Plugin</a>.