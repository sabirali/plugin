<div class="wrap">
	<h2><?php _e('Wordpress Gallery Help &amp; Support','ns_wp_gallery_plugin'); ?></h2>
	<table cellspacing="5" cellpadding="5" border="0" width="100%">
	<tr>
	<td width="70%" valign="top">
		<p><?php _e('For more details about Wordpress Gallery Plugin Please Visit','ns_wp_gallery_plugin'); ?> <a href="http://www.snilesh.com/?p=1242" title="Wordpress Gallery plugin"><?php _e('Wordpress Gallery Plugin','ns_wp_gallery_plugin'); ?></a></p>
	</td>
	<td width="30%" valign="top">
		<?php include_once dirname(__FILE__).'/our_feeds.php'; ?>
	</td>
	</tr>
</table>
</div>